from redshift_utils import Messages
from redshift_utils import ScriptReader
from redshift_utils import RedshiftDataManager
from settings import SCRIPT_PATH
from settings import DB_CONNECTION


def lambda_handler(event, context):
    table_name = event.get('table_name')
    new_table_name = event.get('new_table_name')

    script = ScriptReader.get_script(SCRIPT_PATH).format(table_name, new_table_name)
    return RedshiftDataManager.run_update(script, DB_CONNECTION)