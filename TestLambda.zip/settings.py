###############################################
# Script settings and constants.
###############################################
SCRIPT_PATH = 'script.sql'

DB_CONNECTION = {
    'db_host': 'rscluster2.cw8abie50cul.us-east-1.redshift.amazonaws.com',
    'db_name': 'dev',
    'db_username': 'awsuser',
    'db_password': 'Admin123'
}
